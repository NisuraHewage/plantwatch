
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'nishad',
  applicationName: 'plantwatch',
  appUid: 'TwSrKK45LtPqCnCzvr',
  orgUid: '9b5650f0-3b37-4577-985b-679b166a1f1a',
  deploymentUid: '14e4a209-640c-4d25-88b0-c5d18036531f',
  serviceName: 'ogservice',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.4.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'ogservice-dev-loginUser', timeout: 6 };

try {
  const userHandler = require('./src/functions/loginUser.js');
  module.exports.handler = serverlessSDK.handler(userHandler.loginUser, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}